// r1 r4
#include <stdio.h>
int dict[10];
int main() {
	int a[2];
	int b[2];
	klee_make_symbolic(&a, sizeof a, "a");
  	klee_make_symbolic(&b, sizeof b, "b");
	int output0;
	int output1;
	int sum = 0;
	int x[2];
	int y[2];
	klee_make_symbolic(&x, sizeof x, "x");
  	klee_make_symbolic(&y, sizeof y, "y");
	for (int i = 0; i < 2; i++) {
		output0 = a[i]; //1 The SingleItem pattern Type 1
		sum += b[i];
		int xx = x[i];
		int yy = y[i];
		if (xx >= 0 && xx < 10) dict[xx] = yy; //2 The IndexValuePair pattern Type 1
	}
	output1 = sum;
	printf("%d\n", output0);
	printf("%d\n", output1);
	for (int i = 0; i < 10; i++)
		printf("%d ", dict[i]);
	return 0;
}
