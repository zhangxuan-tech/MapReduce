// r4 r5 r8
#include <stdio.h>
int dict[10], dict2[10];
int flag[10];
int main() {
	int x[2];
	int y[2];
	klee_make_symbolic(&x, sizeof x, "x");
  	klee_make_symbolic(&y, sizeof y, "y");
  	int a[2];
	int b[2];
	klee_make_symbolic(&a, sizeof a, "a");
  	klee_make_symbolic(&b, sizeof b, "b");
	int output0;
	int article = 0;
	int urls[2];
	for (int i = 0; i < 2; i++) {
		int xx = x[i];
		int yy = y[i];
		if (xx >= 0 && xx < 10) dict2[xx] = yy; //2 The IndexValuePair pattern Type 1
		if (xx >= 0 && xx < 10 && !flag[xx]) {
			dict[xx] = yy; //2 The IndexValuePair pattern Type 2
			flag[xx] = 1;
		}
		article = a[i]; //1 The SingleItem pattern Type 1
		urls[i] = b[i]; //5 The StrConcat pattern
	}
	output0 = article;
	printf("%d\n", output0);
	printf("%d %d\n", urls[0], urls[1]);
	for (int i = 0; i < 10; i++)
		printf("%d ", dict[i]);
	printf("\n");
	for (int i = 0; i < 10; i++)
		printf("%d ", dict2[i]);
	return 0;
}
