#include <stdio.h>
int main(){
  int a[2], b[2];
  klee_make_symbolic(&a, sizeof a, "a");
  klee_make_symbolic(&b, sizeof b, "b");
  int last = 0;
  for (int i = 0; i < 2; i++){
    if (a[i] > 68000) last = b[i];
  }
  printf("%d\n", last);
  return 0;
}
