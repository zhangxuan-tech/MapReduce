// r1 r5 r6
#include <stdio.h>
int dict[10];
int flag[10];
int main() {
	int a[2];
	int b[2];
	klee_make_symbolic(&a, sizeof a, "a");
  	klee_make_symbolic(&b, sizeof b, "b");
	int output0;
	int output1;
	int sum = 0;
	int x[2];
	int y[2];
	klee_make_symbolic(&x, sizeof x, "x");
  	klee_make_symbolic(&y, sizeof y, "y");
  	int max = 0;
	int yym = 0;
	for (int i = 0; i < 2; i++) {
		output0 = a[i]; //1 The SingleItem pattern Type 1
		sum += b[i];
		int xx = x[i];
		int yy = y[i];
		if (xx >= 0 && xx < 10 && !flag[xx]) {
			dict[xx] = yy; //2 The IndexValuePair pattern Type 2
			flag[xx] = 1;
		}
		if (max < xx) {
			max = xx;
			yym = y[i]; //3 The MaxRow pattern
		}
	}
	output1 = sum;
	printf("%d\n", output0);
	printf("%d\n", output1);
	printf("%d\n", max);
	printf("%d\n", yym);
	for (int i = 0; i < 10; i++)
		printf("%d ", dict[i]);
	return 0;
}
