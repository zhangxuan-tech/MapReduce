#include <stdio.h>
int main(){
  int id, a[2], b[2];
  klee_make_symbolic(&id, sizeof id, "id");
  klee_make_symbolic(&a, sizeof a, "a");
  klee_make_symbolic(&b, sizeof b, "b");
  int find0 = 0, find1 = 0;
  for (int i = 0; i < 2; i++){
    if (id) {
    	if (!a[i]) find0 = 1;
    }
    else if (b[i]) find1 = 1;
  }
  printf("%d\n", find0);
  printf("%d\n", find1);
  return 0;
}
