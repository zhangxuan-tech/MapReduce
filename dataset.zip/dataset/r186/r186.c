#include <stdio.h>
int main(){
  int id, a[2], b[2];
  klee_make_symbolic(&id, sizeof id, "id");
  klee_make_symbolic(&a, sizeof a, "a");
  klee_make_symbolic(&b, sizeof b, "b");
  int min = 0, sum = 0;
  for (int i = 0; i < 2; i++){
    if (id) {
    	if (a[i] < min) min = a[i];
    }
    else sum += b[i];
  }
  printf("%d\n", min);
  printf("%d\n", sum);
  return 0;
}
