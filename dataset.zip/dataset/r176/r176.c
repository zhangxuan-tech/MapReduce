// r11
#include <stdio.h>
int main() {
	int a[2];
	int b[2];
	klee_make_symbolic(&a, sizeof a, "a");
  	klee_make_symbolic(&b, sizeof b, "b");
	int sum = 0;
	for (int i = 0; i < 2; i++) {
		sum += a[i] + b[i];
	}
	printf("%d\n", sum);
	return 0;
}
