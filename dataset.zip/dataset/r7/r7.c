#include <stdio.h>
int main() {
	int a[2];
	int b[2];
	int c[2];
	int d[2];
	int e[2];
	klee_make_symbolic(&a, sizeof a, "a");
  	klee_make_symbolic(&b, sizeof b, "b");
  	klee_make_symbolic(&c, sizeof c, "c");
  	klee_make_symbolic(&d, sizeof d, "d");
  	klee_make_symbolic(&e, sizeof e, "e");
  	int id = 0;
    	int state = 0;
    	int adid = 0;
    	int clicksTotal = 0;
    	int revenueTotal = 0;
    	for(int i=0;i<2;i++)
    	{
        	id = a[i];
        	state = b[i]; //1 The SingleItem pattern Type 1
        	adid = c[i]; //1 The SingleItem pattern Type 1
        	clicksTotal += d[i];
        	revenueTotal += e[i];
    	}
  	printf("%d\n", id);
  	printf("%d\n", state);
  	printf("%d\n", adid);
  	printf("%d\n", clicksTotal);
  	printf("%d\n", revenueTotal);
	return 0;
}
