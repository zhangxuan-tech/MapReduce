#include <stdio.h>
int main() {
	int a[2];
	int b[2];
	klee_make_symbolic(&a, sizeof a, "a");
  	klee_make_symbolic(&b, sizeof b, "b");
	int output0;
	int output1;
	int sum = 0;
	for (int i = 0; i < 2; i++) {
		output0 = a[i]; //1 The SingleItem pattern Type 1
		sum += b[i];
	}
	output1 = sum;
	printf("%d\n", output0);
	printf("%d\n", output1);
	return 0;
}
