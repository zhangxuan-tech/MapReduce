// r6 r9
#include <stdio.h>
int top, impressions[2][3];
int main() {
	int x[2];
	int y[2];
	klee_make_symbolic(&x, sizeof x, "x");
  	klee_make_symbolic(&y, sizeof y, "y");
	int max = 0;
	int yy = 0;
	int in0[2];
	int in1[2];
	int in3[2];
	int in4[2];
	int in5[2];
	int in6[2];
	int in7[2];
	klee_make_symbolic(&in0, sizeof in0, "in0");
  	klee_make_symbolic(&in1, sizeof in1, "in1");
  	klee_make_symbolic(&in3, sizeof in3, "in3");
  	klee_make_symbolic(&in4, sizeof in4, "in4");
  	klee_make_symbolic(&in5, sizeof in5, "in5");
  	klee_make_symbolic(&in6, sizeof in6, "in6");
  	klee_make_symbolic(&in7, sizeof in7, "in7");
	int special_x = -1, special_y = -1;
	int specialFound = 0;
	for (int i = 0; i < 2; i++) {
		int xx = x[i];
		if (max < xx) {
			max = xx;
			yy = y[i]; //3 The MaxRow pattern
		}
		int isSpecial = in6[i];
		int isImpressions = in7[i];
		if (isSpecial) {
			special_x = in0[i]; //1 The SingleItem pattern Type 2
			special_y = in1[i]; //1 The SingleItem pattern Type 2
			specialFound = 1;
		}
		if (isImpressions) {
			impressions[top][0] = in3[i]; //5 The StrConcat pattern
			impressions[top][1] = in4[i];
			impressions[top][2] = in5[i];
			top++;
		}
		if (specialFound) break;
	}
	printf("%d\n", max);
	printf("%d\n", yy);
	printf("%d %d\n", special_x, special_y);
	for (int i = 0; i < top; i++)
		printf("%d %d %d\n", impressions[i][0], impressions[i][1], impressions[i][2]);
	return 0;
}
