// r60
#include <stdio.h>
int main() {
	int a[2];
	int b[2];
	int d[2];
	int e[2];
	klee_make_symbolic(&a, sizeof a, "a");
  	klee_make_symbolic(&b, sizeof b, "b");
  	klee_make_symbolic(&d, sizeof d, "d");
  	klee_make_symbolic(&e, sizeof e, "e");
    	int clicksTotal = 0;
    	int revenueTotal = 0;
	int sum = 0;
	for (int i = 0; i < 2; i++) {
		sum += a[i] + b[i];
        	clicksTotal += d[i];
        	revenueTotal += e[i];
	}
	printf("%d\n", sum);
  	printf("%d\n", clicksTotal);
  	printf("%d\n", revenueTotal);
	return 0;
}
