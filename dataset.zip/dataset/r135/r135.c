// r3 r7 r8
#include <stdio.h>
int main() {
	int a[2];
	int b[2];
	int c[2];
	klee_make_symbolic(&a, sizeof a, "a");
  	klee_make_symbolic(&b, sizeof b, "b");
  	klee_make_symbolic(&c, sizeof c, "c");
  	int id = 0;
    	int state = 0;
    	int adid = 0;
    	int urls[2];
    	for(int i=0;i<2;i++)
    	{
        	id = a[i];
        	state = b[i]; //1 The SingleItem pattern Type 1
        	adid = c[i]; //1 The SingleItem pattern Type 1
        	urls[i] = b[i]; //5 The StrConcat pattern
    	}
  	printf("%d\n", id);
  	printf("%d\n", state);
  	printf("%d\n", adid);
  	printf("%d %d\n", urls[0], urls[1]);
	return 0;
}
