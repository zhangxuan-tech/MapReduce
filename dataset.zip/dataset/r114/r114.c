// r7 - r2 + r8
#include <stdio.h>
int main() {
	int a[2];
	int b[2];
	klee_make_symbolic(&a, sizeof a, "a");
  	klee_make_symbolic(&b, sizeof b, "b");
	int output0;
	int article = 0;
	int urls[2];
	int d[2];
	int e[2];
  	klee_make_symbolic(&d, sizeof d, "d");
  	klee_make_symbolic(&e, sizeof e, "e");
    	int clicksTotal = 0;
    	int revenueTotal = 0;
    	for(int i=0;i<2;i++)
    	{
        	clicksTotal += d[i];
        	revenueTotal += e[i];
        	article = a[i]; //1 The SingleItem pattern Type 1
		urls[i] = b[i]; //5 The StrConcat pattern
    	}
  	printf("%d\n", clicksTotal);
  	printf("%d\n", revenueTotal);
  	output0 = article;
	printf("%d\n", output0);
	printf("%d %d\n", urls[0], urls[1]);
	return 0;
}
