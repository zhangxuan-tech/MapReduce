// r7 - r1 + r8
#include <stdio.h>
int main() {
	int a[2];
	int c[2];
	int d[2];
	klee_make_symbolic(&a, sizeof a, "a");
  	klee_make_symbolic(&c, sizeof c, "c");
  	klee_make_symbolic(&d, sizeof d, "d");
  	int id = 0;
    	int adid = 0;
    	int clicksTotal = 0;
    	int urls[2];
    	for(int i=0;i<2;i++)
    	{
        	id = a[i];
        	adid = c[i]; //1 The SingleItem pattern Type 1
        	clicksTotal += d[i];
        	urls[i] = a[i]; //5 The StrConcat pattern
    	}
  	printf("%d\n", id);
  	printf("%d\n", adid);
  	printf("%d\n", clicksTotal);
  	printf("%d %d\n", urls[0], urls[1]);
	return 0;
}
