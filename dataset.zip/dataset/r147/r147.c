// r4 r6 r8
#include <stdio.h>
int dict[10];
int main() {
	int a[2];
	int b[2];
	klee_make_symbolic(&a, sizeof a, "a");
  	klee_make_symbolic(&b, sizeof b, "b");
	int output0;
	int article = 0;
	int urls[2];
	int x[2];
	int y[2];
	klee_make_symbolic(&x, sizeof x, "x");
  	klee_make_symbolic(&y, sizeof y, "y");
	int max = 0;
	int yym = 0;
	for (int i = 0; i < 2; i++) {
		article = a[i]; //1 The SingleItem pattern Type 1
		urls[i] = b[i]; //5 The StrConcat pattern
		int xx = x[i];
		int yy = y[i];
		if (xx >= 0 && xx < 10) dict[xx] = yy; //2 The IndexValuePair pattern Type 1
		if (max < xx) {
			max = xx;
			yym = y[i]; //3 The MaxRow pattern
		}
	}
	printf("%d\n", max);
	printf("%d\n", yym);
	output0 = article;
	printf("%d\n", output0);
	printf("%d %d\n", urls[0], urls[1]);
	for (int i = 0; i < 10; i++)
		printf("%d ", dict[i]);
	return 0;
}
