// r3 r6
#include <stdio.h>
int main() {
	int url[2];
	int urlHash[2];
	klee_make_symbolic(&url, sizeof url, "url");
  	klee_make_symbolic(&urlHash, sizeof urlHash, "urlHash");
	int output0;
	int output1;
	int x[2];
	int y[2];
	klee_make_symbolic(&x, sizeof x, "x");
  	klee_make_symbolic(&y, sizeof y, "y");
	int max = 0;
	int yy = 0;
	for (int i = 0; i < 2; i++) {
		output0 = url[i]; //1 The SingleItem pattern Type 1
		output1 = urlHash[i]; //1 The SingleItem pattern Type 1
		int xx = x[i];
		if (max < xx) {
			max = xx;
			yy = y[i]; //3 The MaxRow pattern
		}
	}
	printf("%d\n", output0);
	printf("%d\n", output1);
	printf("%d\n", max);
	printf("%d\n", yy);
	return 0;
}
