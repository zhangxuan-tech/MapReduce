// r2 r4 r7
#include <stdio.h>
int dict[10];
int main() {
	int a[2];
	int b[2];
	int c[2];
	int d[2];
	int e[2];
	klee_make_symbolic(&a, sizeof a, "a");
  	klee_make_symbolic(&b, sizeof b, "b");
  	klee_make_symbolic(&c, sizeof c, "c");
  	klee_make_symbolic(&d, sizeof d, "d");
  	klee_make_symbolic(&e, sizeof e, "e");
	int output0;
	int output1;
	int last = 0;
	int adid = 0;
    	int clicksTotal = 0;
    	int revenueTotal = 0;
	int x[2];
	int y[2];
	klee_make_symbolic(&x, sizeof x, "x");
  	klee_make_symbolic(&y, sizeof y, "y");
	for (int i = 0; i < 2; i++) {
		output0 = a[i]; //1 The SingleItem pattern Type 1
		last = b[i]; //1 The SingleItem pattern Type 1
		adid = c[i]; //1 The SingleItem pattern Type 1
        	clicksTotal += d[i];
        	revenueTotal += e[i];
		int xx = x[i];
		int yy = y[i];
		if (xx >= 0 && xx < 10) dict[xx] = yy; //2 The IndexValuePair pattern Type 1
	}
	output1 = last;
	printf("%d\n", output0);
	printf("%d\n", output1);
	printf("%d\n", adid);
  	printf("%d\n", clicksTotal);
  	printf("%d\n", revenueTotal);
	for (int i = 0; i < 10; i++)
		printf("%d ", dict[i]);
	return 0;
}
