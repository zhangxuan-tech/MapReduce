// r5 r8 r10
#include <stdio.h>
int dict[10];
int flag[10];
int main() {
	int x[3];
	int y[3];
	int z[3];
	klee_make_symbolic(&x, sizeof x, "x");
  	klee_make_symbolic(&y, sizeof y, "y");
  	klee_make_symbolic(&z, sizeof z, "z");
  	int id, mathTotal = 0, englishTotal = 0;
	int a[3];
	int b[3];
	klee_make_symbolic(&a, sizeof a, "a");
  	klee_make_symbolic(&b, sizeof b, "b");
	int output0;
	int article = 0;
	int urls[3];
	for (int i = 0; i < 3; i++) {
		int xx = x[i];
		int yy = y[i];
		if (xx >= 0 && xx < 10 && !flag[xx]) {
			dict[xx] = yy; //2 The IndexValuePair pattern Type 2
			flag[xx] = 1;
		}
		article = a[i]; //1 The SingleItem pattern Type 1
		urls[i] = b[i]; //5 The StrConcat pattern
		if (i < 3) {
			id = x[i]; // 1 SingleItem Type 1
			mathTotal += y[i]; // 4 FirstN
			englishTotal += z[i]; // 4 FirstN
		}
	}
	printf("%d\n", id);
	printf("%d\n", mathTotal);
	printf("%d\n", englishTotal);
	output0 = article;
	printf("%d\n", output0);
	printf("%d %d %d\n", urls[0], urls[1], urls[2]);
	for (int i = 0; i < 10; i++)
		printf("%d ", dict[i]);
	return 0;
}
