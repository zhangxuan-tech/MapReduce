// r1 r8 r10
#include <stdio.h>
int main() {
	int a[3];
	int b[3];
	int c[3];
	klee_make_symbolic(&a, sizeof a, "a");
  	klee_make_symbolic(&b, sizeof b, "b");
  	klee_make_symbolic(&c, sizeof c, "c");
	int output0;
	int article = 0;
	int urls[3];
	int sum = 0;
	int x[3];
	int y[3];
	int z[3];
	klee_make_symbolic(&x, sizeof x, "x");
  	klee_make_symbolic(&y, sizeof y, "y");
  	klee_make_symbolic(&z, sizeof z, "z");
  	int id, mathTotal = 0, englishTotal = 0;
	for (int i = 0; i < 3; i++) {
		article = a[i]; //1 The SingleItem pattern Type 1
		urls[i] = b[i]; //5 The StrConcat pattern
		sum += c[i];
		if (i < 3) {
			id = x[i]; // 1 SingleItem Type 1
			mathTotal += y[i]; // 4 FirstN
			englishTotal += z[i]; // 4 FirstN
		}
	}
	output0 = article;
	printf("%d\n", output0);
	printf("%d %d %d\n", urls[0], urls[1], urls[2]);
	printf("%d\n", sum);
	printf("%d\n", id);
	printf("%d\n", mathTotal);
	printf("%d\n", englishTotal);
	return 0;
}
