// r7 - r2
// commutative
#include <stdio.h>
int main() {
	int d[2];
	int e[2];
  	klee_make_symbolic(&d, sizeof d, "d");
  	klee_make_symbolic(&e, sizeof e, "e");
    int clicksTotal = 0;
    int revenueTotal = 0;
    for(int i=0;i<2;i++)
    {
        clicksTotal += d[i];
        revenueTotal += e[i];
    }
  	printf("%d\n", clicksTotal);
  	printf("%d\n", revenueTotal);
	return 0;
}
