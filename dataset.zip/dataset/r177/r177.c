// r15
#include <stdio.h>
int main() {
	int b[2];
  	klee_make_symbolic(&b, sizeof b, "b");
	int output1;
	int sum = 0;
	int x[2];
	klee_make_symbolic(&x, sizeof x, "x");
	int max = 0;
	for (int i = 0; i < 2; i++) {
		sum += b[i];
		int xx = x[i];
		if (max < xx) {
			max = xx;
		}
	}
	output1 = sum;
	printf("%d\n", output1);
	printf("%d\n", max);
	return 0;
}
