#include <stdio.h>
int main(){
  int id, a[2], b[2];
  klee_make_symbolic(&id, sizeof id, "id");
  klee_make_symbolic(&a, sizeof a, "a");
  klee_make_symbolic(&b, sizeof b, "b");
  int sum = 0, max = 0;
  for (int i = 0; i < 2; i++){
    if (id) sum += a[i];
    else if (b[i] > max) max = b[i];
  }
  printf("%d\n", sum);
  printf("%d\n", max);
  return 0;
}
