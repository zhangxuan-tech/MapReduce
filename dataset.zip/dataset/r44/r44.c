// r67
#include <stdio.h>
int main() {
	int d[2];
	int e[2];
  	klee_make_symbolic(&d, sizeof d, "d");
  	klee_make_symbolic(&e, sizeof e, "e");
    	int clicksTotal = 0;
    	int revenueTotal = 0;
	int val[2];
  	klee_make_symbolic(&val, sizeof val, "val");
	int output2 = 0;
	for (int i = 0; i < 2; i++) {
		output2 += val[i];
        	clicksTotal += d[i];
        	revenueTotal += e[i];
	}
	printf("%d\n", output2);
  	printf("%d\n", clicksTotal);
  	printf("%d\n", revenueTotal);
	return 0;
}
