#include <stdio.h>
int dict[10];
int flag[10];
int main() {
	int x[2];
	int y[2];
	klee_make_symbolic(&x, sizeof x, "x");
  	klee_make_symbolic(&y, sizeof y, "y");
	for (int i = 0; i < 2; i++) {
		int xx = x[i];
		int yy = y[i];
		if (xx >= 0 && xx < 10 && !flag[xx]) {
			dict[xx] = yy; //2 The IndexValuePair pattern Type 2
			flag[xx] = 1;
		}
	}
	for (int i = 0; i < 10; i++)
		printf("%d ", dict[i]);
	return 0;
}
