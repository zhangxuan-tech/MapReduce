#include <stdio.h>
int main() {
	int x[2];
	int y[2];
	klee_make_symbolic(&x, sizeof x, "x");
  	klee_make_symbolic(&y, sizeof y, "y");
	int max = 0;
	int yy = 0;
	for (int i = 0; i < 2; i++) {
		int xx = x[i];
		if (max < xx) {
			max = xx;
			yy = y[i]; //3 The MaxRow pattern
		}
	}
	printf("%d\n", max);
	printf("%d\n", yy);
	return 0;
}
