// r1 r3 r10
#include <stdio.h>
int main() {
	int url[3];
	int urlHash[3];
	int val[3];
	klee_make_symbolic(&url, sizeof url, "url");
  	klee_make_symbolic(&urlHash, sizeof urlHash, "urlHash");
  	klee_make_symbolic(&val, sizeof val, "val");
	int output0;
	int output1;
	int output2 = 0;
	int x[3];
	int y[3];
	int z[3];
	klee_make_symbolic(&x, sizeof x, "x");
  	klee_make_symbolic(&y, sizeof y, "y");
  	klee_make_symbolic(&z, sizeof z, "z");
  	int id, mathTotal = 0, englishTotal = 0;
	for (int i = 0; i < 3; i++) {
		output0 = url[i]; //1 The SingleItem pattern Type 1
		output1 = urlHash[i]; //1 The SingleItem pattern Type 1
		output2 += val[i];
		if (i < 3) {
			id = x[i]; // 1 SingleItem Type 1
			mathTotal += y[i]; // 4 FirstN
			englishTotal += z[i]; // 4 FirstN
		}
	}
	printf("%d\n", output0);
	printf("%d\n", output1);
	printf("%d\n", output2);
	printf("%d\n", id);
	printf("%d\n", mathTotal);
	printf("%d\n", englishTotal);
	return 0;
}
