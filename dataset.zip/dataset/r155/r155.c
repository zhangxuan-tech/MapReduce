// r4 r9 r10
#include <stdio.h>
int top, impressions[3][3];
int dict[10];
int main() {
	int x[3];
	int y[3];
	int z[3];
	klee_make_symbolic(&x, sizeof x, "x");
  	klee_make_symbolic(&y, sizeof y, "y");
  	klee_make_symbolic(&z, sizeof z, "z");
  	int id, mathTotal = 0, englishTotal = 0;
	int in0[3];
	int in1[3];
	int in3[3];
	int in4[3];
	int in5[3];
	int in6[3];
	int in7[3];
	klee_make_symbolic(&in0, sizeof in0, "in0");
  	klee_make_symbolic(&in1, sizeof in1, "in1");
  	klee_make_symbolic(&in3, sizeof in3, "in3");
  	klee_make_symbolic(&in4, sizeof in4, "in4");
  	klee_make_symbolic(&in5, sizeof in5, "in5");
  	klee_make_symbolic(&in6, sizeof in6, "in6");
  	klee_make_symbolic(&in7, sizeof in7, "in7");
	int special_x = -1, special_y = -1;
	int specialFound = 0;
	for (int i = 0; i < 3; i++) {
		int xx = x[i];
		int yy = y[i];
		if (xx >= 0 && xx < 10) dict[xx] = yy; //2 The IndexValuePair pattern Type 1
		int isSpecial = in6[i];
		int isImpressions = in7[i];
		if (isSpecial) {
			special_x = in0[i]; //1 The SingleItem pattern Type 2
			special_y = in1[i]; //1 The SingleItem pattern Type 2
			specialFound = 1;
		}
		if (isImpressions) {
			impressions[top][0] = in3[i]; //5 The StrConcat pattern
			impressions[top][1] = in4[i];
			impressions[top][2] = in5[i];
			top++;
		}
		if (specialFound) break;
		if (i < 3) {
			id = x[i]; // 1 SingleItem Type 1
			mathTotal += y[i]; // 4 FirstN
			englishTotal += z[i]; // 4 FirstN
		}
	}
	printf("%d\n", id);
	printf("%d\n", mathTotal);
	printf("%d\n", englishTotal);
	printf("%d %d\n", special_x, special_y);
	for (int i = 0; i < top; i++)
		printf("%d %d %d\n", impressions[i][0], impressions[i][1], impressions[i][2]);
	for (int i = 0; i < 10; i++)
		printf("%d ", dict[i]);
	return 0;
}
