// r1 r2 r6
#include <stdio.h>
int main() {
	int a[2];
	int b[2];
	klee_make_symbolic(&a, sizeof a, "a");
  	klee_make_symbolic(&b, sizeof b, "b");
	int output0;
	int output1;
	int last = 0, sum = 0;
	int x[2];
	int y[2];
	klee_make_symbolic(&x, sizeof x, "x");
  	klee_make_symbolic(&y, sizeof y, "y");
	int max = 0;
	int yy = 0;
	for (int i = 0; i < 2; i++) {
		output0 = a[i]; //1 The SingleItem pattern Type 1
		last = b[i]; //1 The SingleItem pattern Type 1
		sum += a[i] + b[i];
		int xx = x[i];
		if (max < xx) {
			max = xx;
			yy = y[i]; //3 The MaxRow pattern
		}
	}
	output1 = last;
	printf("%d\n", output0);
	printf("%d\n", output1);
	printf("%d\n", sum);
	printf("%d\n", max);
	printf("%d\n", yy);
	return 0;
}
