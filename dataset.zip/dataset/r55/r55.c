// r49
#include <stdio.h>
int main() {
	int x[2];
	int y[2];
	int z[2];
	klee_make_symbolic(&x, sizeof x, "x");
  	klee_make_symbolic(&y, sizeof y, "y");
  	klee_make_symbolic(&z, sizeof z, "z");
  	int max = 0;
  	int mathTotal = 0, englishTotal = 0;
	for (int i = 0; i < 2; i++) {
		int xx = x[i];
		if (max < xx) {
			max = xx;
		}
		mathTotal += y[i];
		englishTotal += z[i];
	}
	printf("%d\n", max);
	printf("%d\n", mathTotal);
	printf("%d\n", englishTotal);
	return 0;
}
