// r1 r5 r10
#include <stdio.h>
int dict[10];
int flag[10];
int main() {
	int a[3];
	int b[3];
	klee_make_symbolic(&a, sizeof a, "a");
  	klee_make_symbolic(&b, sizeof b, "b");
	int output0;
	int output1;
	int sum = 0;
	int x[3];
	int y[3];
	int z[3];
	klee_make_symbolic(&x, sizeof x, "x");
  	klee_make_symbolic(&y, sizeof y, "y");
  	klee_make_symbolic(&z, sizeof z, "z");
  	int id, mathTotal = 0, englishTotal = 0;
	for (int i = 0; i < 3; i++) {
		output0 = a[i]; //1 The SingleItem pattern Type 1
		sum += b[i];
		int xx = x[i];
		int yy = y[i];
		if (xx >= 0 && xx < 10 && !flag[xx]) {
			dict[xx] = yy; //2 The IndexValuePair pattern Type 2
			flag[xx] = 1;
		}
		if (i < 3) {
			id = x[i]; // 1 SingleItem Type 1
			mathTotal += y[i]; // 4 FirstN
			englishTotal += z[i]; // 4 FirstN
		}
	}
	output1 = sum;
	printf("%d\n", output0);
	printf("%d\n", output1);
	printf("%d\n", id);
	printf("%d\n", mathTotal);
	printf("%d\n", englishTotal);
	for (int i = 0; i < 10; i++)
		printf("%d ", dict[i]);
	return 0;
}
