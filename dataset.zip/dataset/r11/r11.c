// r1 r2
#include <stdio.h>
int main() {
	int a[2];
	int b[2];
	klee_make_symbolic(&a, sizeof a, "a");
  	klee_make_symbolic(&b, sizeof b, "b");
	int output0;
	int output1;
	int last = 0, sum = 0;
	for (int i = 0; i < 2; i++) {
		output0 = a[i]; //1 The SingleItem pattern Type 1
		last = b[i]; //1 The SingleItem pattern Type 1
		sum += a[i] + b[i];
	}
	output1 = last;
	printf("%d\n", output0);
	printf("%d\n", output1);
	printf("%d\n", sum);
	return 0;
}
