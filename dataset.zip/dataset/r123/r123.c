// r3 r4 r8
#include <stdio.h>
int dict[10];
int main() {
	int a[2];
	int b[2];
	klee_make_symbolic(&a, sizeof a, "a");
  	klee_make_symbolic(&b, sizeof b, "b");
	int output2;
	int article = 0;
	int urls[2];
	int url[2];
	int urlHash[2];
	klee_make_symbolic(&url, sizeof url, "url");
  	klee_make_symbolic(&urlHash, sizeof urlHash, "urlHash");
	int output0;
	int output1;
	int x[2];
	int y[2];
	klee_make_symbolic(&x, sizeof x, "x");
  	klee_make_symbolic(&y, sizeof y, "y");
	for (int i = 0; i < 2; i++) {
		output0 = url[i]; //1 The SingleItem pattern Type 1
		output1 = urlHash[i]; //1 The SingleItem pattern Type 1
		int xx = x[i];
		int yy = y[i];
		if (xx >= 0 && xx < 10) dict[xx] = yy; //2 The IndexValuePair pattern Type 1
		article = a[i]; //1 The SingleItem pattern Type 1
		urls[i] = b[i]; //5 The StrConcat pattern
	}
	printf("%d\n", output0);
	printf("%d\n", output1);
	output2 = article;
	printf("%d\n", output2);
	printf("%d %d\n", urls[0], urls[1]);
	for (int i = 0; i < 10; i++)
		printf("%d ", dict[i]);
	return 0;
}
