// r3 r8
#include <stdio.h>
int main() {
	int a[2];
	int b[2];
	int urlHash[2];
	klee_make_symbolic(&a, sizeof a, "a");
  	klee_make_symbolic(&b, sizeof b, "b");
  	klee_make_symbolic(&urlHash, sizeof urlHash, "urlHash");
	int output0, output1;
	int article = 0;
	int urls[2];
	for (int i = 0; i < 2; i++) {
		article = a[i]; //1 The SingleItem pattern Type 1
		urls[i] = b[i]; //5 The StrConcat pattern
		output1 = urlHash[i]; //1 The SingleItem pattern Type 1
	}
	output0 = article;
	printf("%d\n", output0);
	printf("%d\n", output1);
	printf("%d %d\n", urls[0], urls[1]);
	return 0;
}
