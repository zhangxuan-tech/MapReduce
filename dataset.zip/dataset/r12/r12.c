// r1 r3
#include <stdio.h>
int main() {
	int url[2];
	int urlHash[2];
	int val[2];
	klee_make_symbolic(&url, sizeof url, "url");
  	klee_make_symbolic(&urlHash, sizeof urlHash, "urlHash");
  	klee_make_symbolic(&val, sizeof val, "val");
	int output0;
	int output1;
	int output2 = 0;
	for (int i = 0; i < 2; i++) {
		output0 = url[i]; //1 The SingleItem pattern Type 1
		output1 = urlHash[i]; //1 The SingleItem pattern Type 1
		output2 += val[i];
	}
	printf("%d\n", output0);
	printf("%d\n", output1);
	printf("%d\n", output2);
	return 0;
}
