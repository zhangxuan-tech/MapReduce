// r7 - r1
#include <stdio.h>
int main() {
	int a[2];
	int c[2];
	int d[2];
	klee_make_symbolic(&a, sizeof a, "a");
  	klee_make_symbolic(&c, sizeof c, "c");
  	klee_make_symbolic(&d, sizeof d, "d");
  	int id = 0;
    int adid = 0;
    int clicksTotal = 0;
    for(int i=0;i<2;i++)
    {
        id = a[i];
        adid = c[i]; //1 The SingleItem pattern Type 1
        clicksTotal += d[i];
    }
  	printf("%d\n", id);
  	printf("%d\n", adid);
  	printf("%d\n", clicksTotal);
	return 0;
}
