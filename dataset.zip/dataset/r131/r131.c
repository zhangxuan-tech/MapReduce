// r3 r6 r7
#include <stdio.h>
int main() {
	int url[2];
	int urlHash[2];
	klee_make_symbolic(&url, sizeof url, "url");
  	klee_make_symbolic(&urlHash, sizeof urlHash, "urlHash");
	int output0;
	int output1;
	int x[2];
	int y[2];
	klee_make_symbolic(&x, sizeof x, "x");
  	klee_make_symbolic(&y, sizeof y, "y");
	int max = 0;
	int yy = 0;
	int a[2];
	int b[2];
	int c[2];
	int d[2];
	int e[2];
	klee_make_symbolic(&a, sizeof a, "a");
  	klee_make_symbolic(&b, sizeof b, "b");
  	klee_make_symbolic(&c, sizeof c, "c");
  	klee_make_symbolic(&d, sizeof d, "d");
  	klee_make_symbolic(&e, sizeof e, "e");
  	int id = 0;
    	int state = 0;
    	int adid = 0;
    	int clicksTotal = 0;
    	int revenueTotal = 0;
	for (int i = 0; i < 2; i++) {
		output0 = url[i]; //1 The SingleItem pattern Type 1
		output1 = urlHash[i]; //1 The SingleItem pattern Type 1
		int xx = x[i];
		if (max < xx) {
			max = xx;
			yy = y[i]; //3 The MaxRow pattern
		}
		id = a[i];
        	state = b[i]; //1 The SingleItem pattern Type 1
        	adid = c[i]; //1 The SingleItem pattern Type 1
        	clicksTotal += d[i];
        	revenueTotal += e[i];
	}
	printf("%d\n", output0);
	printf("%d\n", output1);
	printf("%d\n", max);
	printf("%d\n", yy);
	printf("%d\n", id);
  	printf("%d\n", state);
  	printf("%d\n", adid);
  	printf("%d\n", clicksTotal);
  	printf("%d\n", revenueTotal);
	return 0;
}
