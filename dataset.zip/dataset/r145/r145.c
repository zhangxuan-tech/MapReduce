// r4 r5 r10
#include <stdio.h>
int dict[10], dict2[10];
int flag[10];
int main() {
	int x[3];
	int y[3];
	int z[3];
	klee_make_symbolic(&x, sizeof x, "x");
  	klee_make_symbolic(&y, sizeof y, "y");
  	klee_make_symbolic(&z, sizeof z, "z");
  	int id, mathTotal = 0, englishTotal = 0;
	for (int i = 0; i < 3; i++) {
		int xx = x[i];
		int yy = y[i];
		if (xx >= 0 && xx < 10) dict2[xx] = yy; //2 The IndexValuePair pattern Type 1
		if (xx >= 0 && xx < 10 && !flag[xx]) {
			dict[xx] = yy; //2 The IndexValuePair pattern Type 2
			flag[xx] = 1;
		}
		if (i < 3) {
			id = x[i]; // 1 SingleItem Type 1
			mathTotal += y[i]; // 4 FirstN
			englishTotal += z[i]; // 4 FirstN
		}
	}
	printf("%d\n", id);
	printf("%d\n", mathTotal);
	printf("%d\n", englishTotal);
	for (int i = 0; i < 10; i++)
		printf("%d ", dict[i]);
	printf("\n");
	for (int i = 0; i < 10; i++)
		printf("%d ", dict2[i]);
	return 0;
}
