// r5 r8 r9
#include <stdio.h>
int top, impressions[2][3];
int dict[10];
int flag[10];
int main() {
	int x[2];
	int y[2];
	klee_make_symbolic(&x, sizeof x, "x");
  	klee_make_symbolic(&y, sizeof y, "y");
	int a[2];
	int b[2];
	klee_make_symbolic(&a, sizeof a, "a");
  	klee_make_symbolic(&b, sizeof b, "b");
	int output0;
	int article = 0;
	int urls[2];
	int in0[2];
	int in1[2];
	int in3[2];
	int in4[2];
	int in5[2];
	int in6[2];
	int in7[2];
	klee_make_symbolic(&in0, sizeof in0, "in0");
  	klee_make_symbolic(&in1, sizeof in1, "in1");
  	klee_make_symbolic(&in3, sizeof in3, "in3");
  	klee_make_symbolic(&in4, sizeof in4, "in4");
  	klee_make_symbolic(&in5, sizeof in5, "in5");
  	klee_make_symbolic(&in6, sizeof in6, "in6");
  	klee_make_symbolic(&in7, sizeof in7, "in7");
	int special_x = -1, special_y = -1;
	int specialFound = 0;
	for (int i = 0; i < 2; i++) {
		int xx = x[i];
		int yy = y[i];
		if (xx >= 0 && xx < 10 && !flag[xx]) {
			dict[xx] = yy; //2 The IndexValuePair pattern Type 2
			flag[xx] = 1;
		}
		article = a[i]; //1 The SingleItem pattern Type 1
		urls[i] = b[i]; //5 The StrConcat pattern
		int isSpecial = in6[i];
		int isImpressions = in7[i];
		if (isSpecial) {
			special_x = in0[i]; //1 The SingleItem pattern Type 2
			special_y = in1[i]; //1 The SingleItem pattern Type 2
			specialFound = 1;
		}
		if (isImpressions) {
			impressions[top][0] = in3[i]; //5 The StrConcat pattern
			impressions[top][1] = in4[i];
			impressions[top][2] = in5[i];
			top++;
		}
		if (specialFound) break;
	}
	output0 = article;
	printf("%d\n", output0);
	printf("%d %d\n", urls[0], urls[1]);
	printf("%d %d\n", special_x, special_y);
	for (int i = 0; i < top; i++)
		printf("%d %d %d\n", impressions[i][0], impressions[i][1], impressions[i][2]);
	for (int i = 0; i < 10; i++)
		printf("%d ", dict[i]);
	return 0;
}
