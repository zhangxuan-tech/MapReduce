#include <stdio.h>
int main() {
	int url[2];
	int urlHash[2];
	klee_make_symbolic(&url, sizeof url, "url");
  	klee_make_symbolic(&urlHash, sizeof urlHash, "urlHash");
	int output0;
	int output1;
	for (int i = 0; i < 2; i++) {
		output0 = url[i]; //1 The SingleItem pattern Type 1
		output1 = urlHash[i]; //1 The SingleItem pattern Type 1
	}
	printf("%d\n", output0);
	printf("%d\n", output1);
	return 0;
}
