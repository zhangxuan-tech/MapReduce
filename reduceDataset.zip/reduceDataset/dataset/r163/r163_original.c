#include <stdio.h>
typedef struct {
    int id;
    int a;
    int b;
} Row;
typedef struct {
    Row *rows;
    int rowCount;
} ReduceInput;
void reduce(ReduceInput* input) {
    int max = 0, sum = 0;
    for (int i = 0; i < input->rowCount; i++) {
        Row row = input->rows[i];
        if (row.id) {
            if (row.a > max) {
                max = row.a;
            }
        } else {
            sum += row.b;
        }
    }
    printf("%d\n", max);
    printf("%d\n", sum);
}
