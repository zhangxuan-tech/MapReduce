import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;
import java.io.IOException;
public static class CustomReducer extends Reducer<Text, IntWritable, Text, IntWritable> {
    private IntWritable maxResult = new IntWritable();
    private IntWritable sumResult = new IntWritable();
    @Override
    public void reduce(Text key, Iterable<IntWritable> values, Context context) throws IOException, InterruptedException {
        int max = 0;
        int sum = 0;
        for (IntWritable val : values) {
            if ( true) {
                if (val.get() > max) {
                    max = val.get();
                }
            } else {
                sum += val.get();
            }
        }
        maxResult.set(max);
        sumResult.set(sum);
        context.write(new Text("max"), maxResult);
        context.write(new Text("sum"), sumResult);
    }
}
