#include <stdio.h>
#include <stdlib.h>
typedef struct {
    int a;
    int b;
    int in6;
    int in7;
    int in0;
    int in1;
    int in3;
    int in4;
    int in5;
} Row;
typedef struct {
    Row *rows;
    int rowCount;
} ReduceInput;
int top = 0;
int impressions[100][3];
void reduce(ReduceInput *input) {
    int output0;
    int output1;
    int last = 0, sum = 0;
    int special_x = -1, special_y = -1;
    int specialFound = 0;
    for (int i = 0; i < input->rowCount; i++) {
        Row row = input->rows[i];
        output0 = row.a; 
        last = row.b; 
        sum += row.a + row.b;
        int isSpecial = row.in6;
        int isImpressions = row.in7;
        if (isSpecial) {
            special_x = row.in0; 
            special_y = row.in1;
            specialFound = 1;
        }
        if (isImpressions && top < 100) {
            impressions[top][0] = row.in3; 
            impressions[top][1] = row.in4;
            impressions[top][2] = row.in5;
            top++;
        }
        if (specialFound) break;
    }
    output1 = last;
    printf("%d\n", output0);
    printf("%d\n", output1);
    printf("%d\n", sum);
    printf("%d %d\n", special_x, special_y);
    for (int i = 0; i < top; i++)
        printf("%d %d %d\n", impressions[i][0], impressions[i][1], impressions[i][2]);
}
