import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;
import java.io.IOException;
public class CStyleReducer extends Reducer<Text, Text, Text, Text> {
    private Text output0Text = new Text();
    private Text output1Text = new Text();
    private Text sumText = new Text();
    private Text specialXYText = new Text();
    private StringBuilder impressionsBuilder = new StringBuilder();
    @Override
    protected void reduce(Text key, Iterable<Text> values, Context context) throws IOException, InterruptedException {
        int output0 = 0;
        int output1 = 0;
        int last = 0;
        int sum = 0;
        int special_x = -1;
        int special_y = -1;
        int specialFound = 0;
        int top = 0;
        int[][] impressions = new int[100][3]; 
        for (Text value : values) {
            String[] parts = value.toString().split(",");
            output0 = Integer.parseInt(parts[0]);
            last = Integer.parseInt(parts[1]);
            sum += output0 + last;
            int isSpecial = Integer.parseInt(parts[2]);
            int isImpressions = Integer.parseInt(parts[3]);
            if (isSpecial) {
                special_x = Integer.parseInt(parts[4]);
                special_y = Integer.parseInt(parts[5]);
                specialFound = 1;
            }
            if (isImpressions) {
                impressions[top][0] = Integer.parseInt(parts[6]);
                impressions[top][1] = Integer.parseInt(parts[7]);
                impressions[top][2] = Integer.parseInt(parts[8]);
                top++;
            }
            if (specialFound) break;
        }
        output1 = last;
        output0Text.set(Integer.toString(output0));
        output1Text.set(Integer.toString(output1));
        sumText.set(Integer.toString(sum));
        specialXYText.set(special_x + " " + special_y);
        context.write(new Text("output0"), output0Text);
        context.write(new Text("output1"), output1Text);
        context.write(new Text("sum"), sumText);
        context.write(new Text("special_x_y"), specialXYText);
        for (int i = 0; i < top; i++) {
            impressionsBuilder.setLength(0);
            impressionsBuilder.append(impressions[i][0]).append(" ").append(impressions[i][1]).append(" ").append(impressions[i][2]);
            context.write(new Text("impressions"), new Text(impressionsBuilder.toString()));
        }
    }
}
