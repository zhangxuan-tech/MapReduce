import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;
import java.io.IOException;
public class CustomReducer extends Reducer<Text, Text, Text, Text> {
    private int[] dict = new int[10];
    private int[] flag = new int[10];
    @Override
    protected void reduce(Text key, Iterable<Text> values, Context context) throws IOException, InterruptedException {
        int id = 0;
        int state = 0;
        int adid = 0;
        int clicksTotal = 0;
        int revenueTotal = 0;
        int[] urls = new int[2];
        for (Text value : values) {
            String[] parts = value.toString().split(",");
            int xx = Integer.parseInt(parts[0]);
            int yy = Integer.parseInt(parts[1]);
            if (xx >= 0 && xx < 10 && flag[xx] == 0) {
                dict[xx] = yy;
                flag[xx] = 1;
            }
            id = Integer.parseInt(parts[2]);
            state = Integer.parseInt(parts[3]);
            adid = Integer.parseInt(parts[4]);
            clicksTotal += Integer.parseInt(parts[5]);
            revenueTotal += Integer.parseInt(parts[6]);
            urls[Integer.parseInt(parts[7])] = Integer.parseInt(parts[8]);
        }
        context.write(new Text("id"), new Text(String.valueOf(id)));
        context.write(new Text("state"), new Text(String.valueOf(state)));
        context.write(new Text("adid"), new Text(String.valueOf(adid)));
        context.write(new Text("clicksTotal"), new Text(String.valueOf(clicksTotal)));
        context.write(new Text("revenueTotal"), new Text(String.valueOf(revenueTotal)));
        context.write(new Text("urls"), new Text(urls[0] + " " + urls[1]));
        StringBuilder dictBuilder = new StringBuilder();
        for (int i = 0; i < 10; i++) {
            dictBuilder.append(dict[i]).append(" ");
        }
        context.write(new Text("dict"), new Text(dictBuilder.toString()));
    }
}
