#include <stdio.h>
typedef struct {
    int x;
    int y;
    int a;
    int b;
    int c;
    int d;
    int e;
} Row;
typedef struct {
    Row rows[100]; 
    int size;
} ReduceInput;
int dict[10];
int flag[10];
void reduce(ReduceInput* input) {
    int id = 0;
    int state = 0;
    int adid = 0;
    int clicksTotal = 0;
    int revenueTotal = 0;
    int urls[2];
    for (int i = 0; i < input->size; i++) {
        Row row = input->rows[i];
        int xx = row.x;
        int yy = row.y;
        if (xx >= 0 && xx < 10 &&!flag[xx]) {
            dict[xx] = yy; 
            flag[xx] = 1;
        }
        id = row.a;
        state = row.b; 
        adid = row.c; 
        clicksTotal += row.d;
        revenueTotal += row.e;
        urls[i % 2] = row.b; 
    }
    printf("%d\n", id);
    printf("%d\n", state);
    printf("%d\n", adid);
    printf("%d\n", clicksTotal);
    printf("%d\n", revenueTotal);
    printf("%d %d\n", urls[0], urls[1]);
    for (int i = 0; i < 10; i++)
        printf("%d ", dict[i]);
}
