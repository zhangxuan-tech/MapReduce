import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;
import java.io.IOException;
public class CustomReducer extends Reducer<Text, Text, Text, IntWritable> {
    private IntWritable output0 = new IntWritable();
    private IntWritable output1 = new IntWritable();
    private IntWritable last = new IntWritable();
    @Override
    public void reduce(Text key, Iterable<Text> values, Context context) throws IOException, InterruptedException {
        for (Text value : values) {
            int urlValue = parseValue(value, "url");
            int urlHashValue = parseValue(value, "urlHash");
            int aValue = parseValue(value, "a");
            output0.set(urlValue);
            output1.set(urlHashValue);
            last.set(aValue);
        }
        context.write(new Text("output0"), output0);
        context.write(new Text("output1"), output1);
        context.write(new Text("last"), last);
    }
    private int parseValue(Text value, String fieldName) {
        return 0;
    }
}
