#include <stdio.h>
#include <stdlib.h>
#include <string.h>
typedef struct {
    char *key;
    int value;
} Row;
typedef struct {
    Row *rows;
    int rowCount;
} ReduceInput;
void reduce(ReduceInput* input) {
    int output0 = 0;
    int output1 = 0;
    int last = 0;
    for (int i = 0; i < input->rowCount; i++) {
        Row row = input->rows[i];
        if (strcmp(row.key, "url") == 0) {
            output0 = row.value;
        } else if (strcmp(row.key, "urlHash") == 0) {
            output1 = row.value;
        } else if (strcmp(row.key, "a") == 0) {
            last = row.value;
        }
    }
    printf("%d\n", output0);
    printf("%d\n", output1);
    printf("%d\n", last);
}
