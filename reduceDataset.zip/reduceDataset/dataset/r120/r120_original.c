#include <stdio.h>
#include <stdlib.h>
typedef struct {
    int url;
    int urlHash;
    int x;
    int y;
} Row;
typedef struct {
    Row *rows;
    int size;
} ReduceInput;
int dict[10];
int dict2[10];
int flag[10];
void reduce(ReduceInput* input) {
    int output0;
    int output1;
    for (int i = 0; i < input->size; i++) {
        Row row = input->rows[i];
        output0 = row.url;
        output1 = row.urlHash;
        int xx = row.x;
        int yy = row.y;
        if (xx >= 0 && xx < 10) dict[xx] = yy;
        if (xx >= 0 && xx < 10 &&!flag[xx]) {
            dict2[xx] = yy;
            flag[xx] = 1;
        }
    }
    printf("%d\n", output0);
    printf("%d\n", output1);
    for (int i = 0; i < 10; i++)
        printf("%d ", dict[i]);
    printf("\n");
    for (int i = 0; i < 10; i++)
        printf("%d ", dict2[i]);
    printf("\n");
}
