import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;
import java.io.IOException;
public class CustomReducer extends Reducer<Text, Text, Text, IntWritable> {
    private IntWritable output0Writable = new IntWritable();
    private IntWritable output1Writable = new IntWritable();
    private int[] dict = new int[10];
    private int[] dict2 = new int[10];
    private int[] flag = new int[10];
    @Override
    protected void reduce(Text key, Iterable<Text> values, Context context) throws IOException, InterruptedException {
        for (Text value : values) {
            String[] parts = value.toString().split(",");
            int output0 = Integer.parseInt(parts[0]);
            int output1 = Integer.parseInt(parts[1]);
            int xx = Integer.parseInt(parts[2]);
            int yy = Integer.parseInt(parts[3]);
            output0Writable.set(output0);
            output1Writable.set(output1);
            if (xx >= 0 && xx < 10) {
                dict[xx] = yy;
            }
            if (xx >= 0 && xx < 10 && flag[xx] == 0) {
                dict2[xx] = yy;
                flag[xx] = 1;
            }
        }
        context.write(new Text("output0"), output0Writable);
        context.write(new Text("output1"), output1Writable);
        for (int i = 0; i < 10; i++) {
            context.write(new Text("dict[" + i + "]"), new IntWritable(dict[i]));
        }
        for (int i = 0; i < 10; i++) {
            context.write(new Text("dict2[" + i + "]"), new IntWritable(dict2[i]));
        }
    }
}
