import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
class Row {
    private Map<String, Integer> data;
    public Row(Map<String, Integer> data) {
        this.data = data;
    }
    public int getInteger(String key) {
        return data.get(key);
    }
}
class ReduceInput {
    private List<Row> rows;
    public ReduceInput(List<Row> rows) {
        this.rows = rows;
    }
    public Iterator<Row> iterator() {
        return rows.iterator();
    }
}
public class CustomReducer {
    public static void reduce(ReduceInput input) {
        int output0 = 0, output1 = 0;
        int article = 0;
        int[] urls = new int[2];
        for (Row row : input) {
            article = row.getInteger("a"); 
            urls[0] = row.getInteger("b"); 
            output1 = row.getInteger("c"); 
        }
        output0 = article;
        System.out.println(output0);
        System.out.println(output1);
        System.out.println(urls[0] + " " + urls[1]);
    }
    public static void main(String[] args) {
        List<Row> rows = new ArrayList<>();
        Map<String, Integer> rowData1 = new HashMap<>();
        rowData1.put("a", 1);
        rowData1.put("b", 2);
        rowData1.put("c", 3);
        rows.add(new Row(rowData1));
        ReduceInput input = new ReduceInput(rows);
        reduce(input);
    }
}
