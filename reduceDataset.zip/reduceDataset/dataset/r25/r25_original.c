#include <stdio.h>
#include <stdlib.h>
typedef struct {
    int a;
    int b;
    int c;
} Row;
typedef struct {
    Row* data;
    int length;
} ReduceInput;
void reduce(ReduceInput* input) {
    int output0 = 0, output1 = 0;
    int article = 0;
    int urls[2] = {0};
    for (int i = 0; i < input->length; i++) {
        Row row = input->data[i];
        article = row.a; 
        urls[0] = row.b; 
        output1 = row.c; 
    }
    output0 = article;
    printf("%d\n", output0);
    printf("%d\n", output1);
    printf("%d %d\n", urls[0], urls[1]);
}
