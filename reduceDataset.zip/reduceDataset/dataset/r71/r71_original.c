#include <stdio.h>
#include <stdlib.h>
typedef struct {
    int a;
    int b;
    int x;
    int y;
} Row;
typedef struct {
    Row *rows;
    int size;
} ReduceInput;
int dict[10];
int dict2[10], flag[10];
void reduce(ReduceInput *input) {
    int output0 = 0;
    int output1 = 0;
    int sum = 0;
    for (int i = 0; i < input->size; i++) {
        Row row = input->rows[i];
        output0 = row.a; 
        sum += row.b;
        int xx = row.x;
        int yy = row.y;
        if (xx >= 0 && xx < 10) dict[xx] = yy; 
        if (xx >= 0 && xx < 10 &&!flag[xx]) {
            dict2[xx] = yy; 
            flag[xx] = 1;
        }
    }
    output1 = sum;
    printf("%d\n", output0);
    printf("%d\n", output1);
    for (int i = 0; i < 10; i++)
        printf("%d ", dict[i]);
    printf("\n");
    for (int i = 0; i < 10; i++)
        printf("%d ", dict2[i]);
    printf("\n");
}
