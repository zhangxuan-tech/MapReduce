import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;
import java.io.IOException;
public class CustomReducer extends Reducer<Text, Row, Text, IntWritable> {
    private IntWritable output0Writable = new IntWritable();
    private IntWritable output1Writable = new IntWritable();
    private int[] dict = new int[10];
    private int[] dict2 = new int[10];
    private int[] flag = new int[10];
    @Override
    public void reduce(Text key, Iterable<Row> values, Context context) throws IOException, InterruptedException {
        int output0 = 0;
        int output1 = 0;
        int sum = 0;
        for (Row row : values) {
            output0 = row.get("a").get(); 
            sum += row.get("b").get();
            int xx = row.get("x").get();
            int yy = row.get("y").get();
            if (xx >= 0 && xx < 10) dict[xx] = yy; 
            if (xx >= 0 && xx < 10 && flag[xx] == 0) {
                dict2[xx] = yy; 
                flag[xx] = 1;
            }
        }
        output1 = sum;
        output0Writable.set(output0);
        output1Writable.set(output1);
        context.write(new Text("output0"), output0Writable);
        context.write(new Text("output1"), output1Writable);
        StringBuilder dictBuilder = new StringBuilder();
        for (int i = 0; i < 10; i++) {
            dictBuilder.append(dict[i]).append(" ");
        }
        context.write(new Text("dict"), new IntWritable(Integer.parseInt(dictBuilder.toString().trim())));
        StringBuilder dict2Builder = new StringBuilder();
        for (int i = 0; i < 10; i++) {
            dict2Builder.append(dict2[i]).append(" ");
        }
        context.write(new Text("dict2"), new IntWritable(Integer.parseInt(dict2Builder.toString().trim())));
    }
}
class Row {
    private final IntWritable a;
    private final IntWritable b;
    private final IntWritable x;
    private final IntWritable y;
    public Row(IntWritable a, IntWritable b, IntWritable x, IntWritable y) {
        this.a = a;
        this.b = b;
        this.x = x;
        this.y = y;
    }
    public IntWritable get(String field) {
        switch (field) {
            case "a":
                return a;
            case "b":
                return b;
            case "x":
                return x;
            case "y":
                return y;
            default:
                return null;
        }
    }
}
