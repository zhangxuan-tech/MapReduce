import java.io.IOException;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;
public static class CustomReducer extends Reducer<Text, Text, Text, IntWritable> {
    private IntWritable output0Writable = new IntWritable();
    private IntWritable output1Writable = new IntWritable();
    private IntWritable output2Writable = new IntWritable();
    private Text specialText = new Text();
    private StringBuilder impressionsBuilder = new StringBuilder();
    @Override
    public void reduce(Text key, Iterable<Text> values, Context context) throws IOException, InterruptedException {
        int output0 = 0;
        int output1 = 0;
        int output2 = 0;
        int special_x = -1, special_y = -1;
        int specialFound = 0;
        int top = 0;
        int[][] impressions = new int[100][3]; 
        for (Text value : values) {
            String[] parts = value.toString().split(",");
            output0 = Integer.parseInt(parts[0]);
            output1 = Integer.parseInt(parts[1]);
            output2 += Integer.parseInt(parts[2]);
            int isSpecial = Integer.parseInt(parts[3]);
            int isImpressions = Integer.parseInt(parts[4]);
            if (isSpecial) {
                special_x = Integer.parseInt(parts[5]);
                special_y = Integer.parseInt(parts[6]);
                specialFound = 1;
            }
            if (isImpressions) {
                impressions[top][0] = Integer.parseInt(parts[7]);
                impressions[top][1] = Integer.parseInt(parts[8]);
                impressions[top][2] = Integer.parseInt(parts[9]);
                top++;
            }
            if (specialFound) break;
        }
        output0Writable.set(output0);
        output1Writable.set(output1);
        output2Writable.set(output2);
        specialText.set(special_x + " " + special_y);
        context.write(new Text("output0"), output0Writable);
        context.write(new Text("output1"), output1Writable);
        context.write(new Text("output2"), output2Writable);
        context.write(new Text("special"), specialText);
        for (int i = 0; i < top; i++) {
            impressionsBuilder.setLength(0);
            impressionsBuilder.append(impressions[i][0]).append(" ").append(impressions[i][1]).append(" ").append(impressions[i][2]);
            context.write(new Text("impressions"), new IntWritable(Integer.parseInt(impressionsBuilder.toString())));
        }
    }
}
