#include <stdio.h>
typedef struct {
    int url;
    int urlHash;
    int val;
    int in0;
    int in1;
    int in3;
    int in4;
    int in5;
    int in6;
    int in7;
} Row;
typedef struct {
    Row *rows;
    int size;
} ReduceInput;
#define IMPRESSIONS_SIZE 100
int top = 0;
int impressions[IMPRESSIONS_SIZE][3];
void reduce(ReduceInput *input) {
    int output0 = 0;
    int output1 = 0;
    int output2 = 0;
    int special_x = -1, special_y = -1;
    int specialFound = 0;
    for (int i = 0; i < input->size; i++) {
        Row row = input->rows[i];
        output0 = row.url;
        output1 = row.urlHash;
        output2 += row.val;
        int isSpecial = row.in6;
        int isImpressions = row.in7;
        if (isSpecial) {
            special_x = row.in0;
            special_y = row.in1;
            specialFound = 1;
        }
        if (isImpressions) {
            if (top < IMPRESSIONS_SIZE) {
                impressions[top][0] = row.in3;
                impressions[top][1] = row.in4;
                impressions[top][2] = row.in5;
                top++;
            }
        }
        if (specialFound) break;
    }
    printf("%d\n", output0);
    printf("%d\n", output1);
    printf("%d\n", output2);
    printf("%d %d\n", special_x, special_y);
    for (int i = 0; i < top; i++)
        printf("%d %d %d\n", impressions[i][0], impressions[i][1], impressions[i][2]);
}
